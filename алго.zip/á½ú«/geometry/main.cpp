#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

struct Point {
    int x, y;
    Point(const int &x0, const int &y0){
        x = x0; y = y0;
    }
    Point(){
        x = 0; y = 0;
    }
};

struct Vector {
    int x, y;
    Vector(const int &x0, const int &y0){
        x = x0; y = y0;
    }
    Vector(){
        x = 0; y = 0;
    }
    Vector(Point &A, Point &B){
        x = B.x - A.x;
        y = B.y - A.y;
    }
};

int vec_prod (Vector &A, Vector &B){
    return A.x*B.y - A.y*B.x;
}

int scal_prod (Vector &A, Vector &B){
    return A.x*B.x + A.y*B.y;
}

istream &operator>> (istream &in, Point &P){
    in >> P.x >> P.y;
    return in;
}

istream &operator>> (istream &in, Vector &V){
    in >> V.x >> V.y;
    return in;
}

double len(Point &A, Point &B){
    return sqrt(double((B.x-A.x) * (B.x-A.x) + (B.y-A.y) * (B.y-A.y)));
}

int main()
{
    Point A, B, C;
    cin >> A >> B >> C;
    Vector BC(B, C), BA(B, A);
    int cross = vec_prod(BA, BC);
    int scal = scal_prod(BC, BA);
    if(scal < 0)cout << len(A, B);
    else cout << abs(double(cross) /  len(B, C));
    return 0;
}
