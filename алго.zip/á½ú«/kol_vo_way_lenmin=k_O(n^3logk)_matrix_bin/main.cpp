#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
const ll inf = 1000000000;
typedef double db;
typedef pair<ll, ll> pii;
typedef pair<ll, ll> pll;
const ll mod1 = (1ll<<55)-55;//2^55-55
const ll mod2 = (1ll<<45)-55;//2^45-55

vector<vector<int> > v, answ, dop;
int kol_vo, k;

void prin(vector<vector<int> > a){
    for(int c=0; c<a.size(); c++){
        for(int i=0; i<a[c].size(); i++)
            cout << a[c][i] << " ";
        cout << endl;
    }
}

void init(){
    v.resize(kol_vo*2);
    for(int c=0; c<kol_vo*2; c++)
        v[c].resize(kol_vo*2);
    answ = v;
}

vector<vector<int> > mul(vector<vector<int> > a, vector<vector<int> > &b){
    for(int i=0; i<a.size(); i++){
        for(int j=0; j<a[i].size(); j++){
            int kol = 0;
            for(int k=0; k<a[i].size(); k++){
                kol += (a[i][k] * b[k][j]);
            }
            answ[i][j] = kol;
        }
    }
    //����� ������ i <= a.size()/2 � ����� ������ �� ����� ���������� �������� � [kol_vo][kol_vo] kol_vo+1 � ��
    return answ;
}

vector<vector<int> > mpow(vector<vector<int> > &a, int n){
    if(n == 1)return a;
    if(n % 2)return mul(mpow(a, n-1), a);
    else {
        dop = mpow(a, n/2);
        prin(mul(dop, dop));
        cout << endl << endl;
        return mul(dop, dop);
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cin >> kol_vo >> k;
    init();
    for(int c=0; c<kol_vo; c++){
        for(int i=0; i<kol_vo; i++)
            cin >> v[c][i];
    }
    for(int c=0; c<kol_vo; c++)
        v[c][c+kol_vo] = 1;
    for(int c=kol_vo; c<kol_vo*2; c++)
        v[c][c] = 1;
    prin(v);
    cout << endl << endl;
    vector<vector<int> > an = mpow(v, k+1);
    prin(an);
    cout << endl << endl;
    int ask; cin >> ask;
    for(int c=0; c<ask; c++){
        int from, to;
        cin >> from >> to;
        from--; to--;
        cout << from+1 << " " << to+1 << "   ";
        cout << an[from][to+kol_vo] + (from == to ? -1 : 0) << endl;
        //cout << an[from][to+kol_vo] - 1 << endl;
        //cout << an[from][to+kol_vo] << endl;
    }
    return 0;
}
