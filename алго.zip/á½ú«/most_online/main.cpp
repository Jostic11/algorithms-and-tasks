#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

vector<int> dvus, comp, pr, ssize;
int kol_vo_ver, kol_vo_reb, cu = 0, bridge;
const int max_ver = 100005;

void init(){
    for(int c=0; c<kol_vo_ver; c++){
        comp[c] = dvus[c] = c;
        ssize[c] = 1;
        pr[c] = -1;
    }
    bridge = 0;
}

int get_dvus(int ver){
    if(ver == -1)return -1;
    return dvus[ver] == ver ? ver : dvus[ver] = get_dvus(dvus[ver]);
}

int get_comp(int ver){
    ver = get_dvus(ver);
    return comp[ver] == ver ? ver : comp[ver] = get_comp(comp[ver]);
}

vector<int> used(max_ver);

void merge_path(int a, int b){
    cu++;
    vector<int> va, vb;
    int lca = -1;
    while(true){
        if(a != -1){
            a = get_dvus(a);
            va.push_back(a);
            if(used[a] == cu){
                lca = a;
                break;
            }
            used[a] = cu;
            a = pr[a];
        }
        if(b != -1){
            b = get_dvus(b);
            vb.push_back(b);
            if(used[b] == cu){
                lca = b;
                break;
            }
            used[b] = cu;
            b = pr[b];
        }
    }
    for(int i=0; i<va.size(); i++){
        dvus[va[i]] = lca;
        if(va[i] == lca)break;
        bridge--;
    }
    for(int i=0; i<vb.size(); i++){
        dvus[vb[i]] = lca;
        if(vb[i] == lca)break;
        bridge--;
    }
}

void make_root(int ver){
    ver = get_dvus(ver);
    int root = ver, child = -1;
    while(ver != -1){
        int p = get_dvus(pr[ver]);
        pr[ver] = child;
        comp[ver] = root;
        child = ver;
        ver = p;
    }
    ssize[root] = ssize[child];
}

void add_edge(int a, int b){
    a = get_dvus(a);
    b = get_dvus(b);
    int ac = get_comp(a), bc = get_comp(b);
    if(ac != bc){
        bridge++;
        if(ssize[ac] > ssize[bc]){
            swap(ac, bc);
            swap(a, b);
        }
        make_root(a);
        pr[a] = comp[a] = b;
        ssize[bc] += ssize[a];
    }
    else merge_path(a, b);
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    cin >> kol_vo_ver >> kol_vo_reb;
    dvus.resize(kol_vo_ver); comp.resize(kol_vo_ver);
    ssize.resize(kol_vo_ver); pr.resize(kol_vo_ver);
    init();
    for(int c=0; c<kol_vo_reb; c++){
        int e, e1;
        cin >> e >> e1;
        e--; e1--;
        add_edge(e, e1);
        cout << bridge << endl;
    }
    return 0;
}
