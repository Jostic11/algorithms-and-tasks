#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main()
{
    string s;
    cin >> s;
    int n = s.length();
    vector<vector<int> > v(n, vector<int> (n));
    for(int c=0; c<n; c++)
        v[c][c] = 1;
    for(int c=n-2; c>=0; c--){
        for(int i=c+1; i<n; i++){
            if(s[c] == s[i])v[c][i] = v[c+1][i-1]+2;
            else v[c][i] = max(v[c+1][i], v[c][i-1]);
        }
    }
    int len = v[0][n-1];
    cout << len << endl;
    vector<char> answ(len);
    int l=0, r=n-1, la=0, lr=len-1;
    while(l <= r){
        if(s[l] == s[r]){
            answ[la] = answ[lr] = s[l];
            la++; lr--;
            l++; r--;
        }
        else {
            if(v[l+1][r] > v[l][r-1])l++;
            else r--;
        }
    }
    for(int c=0; c<len; c++)
        cout << answ[c];
    return 0;
}
