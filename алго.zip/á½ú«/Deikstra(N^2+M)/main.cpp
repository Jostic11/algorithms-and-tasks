#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const int inf = 1000000000;

int main()
{
    int kol_vo_ver, kol_vo_reb;
    cin >> kol_vo_ver >> kol_vo_reb;
    vector<vector<pair<int, int> > > v(kol_vo_ver);
    vector<bool> used(kol_vo_ver);
    vector<int> dist(kol_vo_ver, inf), pr(kol_vo_ver);
    dist[0] = 0;
    for(int c=0; c<kol_vo_reb; c++){
        int e, e1, len;
        cin >> e >> e1 >> len;
        e--; e1--;
        v[e].push_back({e1, len});
        v[e1].push_back({e, len});
    }
    for(int c=0; c<kol_vo_ver; c++){
        int ver = -1;
        for(int i=0; i<kol_vo_ver; i++)
            if(!used[i] && (ver == -1 || dist[i] < dist[ver]))ver = i;
        if(dist[ver] == inf)break;
        used[ver] = true;
        for(int c=0; c<v[ver].size(); c++){
            int to = v[ver][c].first;
            int len = v[ver][c].second;
            if(dist[ver] + len < dist[to]){
                dist[to] = dist[ver] + len;
                pr[to] = ver;
            }
        }
    }
    for(auto i : dist)
        cout << i << " ";
    return 0;
}
