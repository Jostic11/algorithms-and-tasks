#include <bits/stdc++.h>

using namespace std;

vector<char> used;
vector<int> lca_dfs_list, lca_h, lca_first;
vector<vector<int> > v;
int kol_vo_ver, kol_vo_reb;
const int inf = 1000000000;

void lca_dfs(int ver, int h){
    used[ver] = true;
    lca_h[ver] = h;
    lca_dfs_list.push_back(ver);
    for(auto to : v[ver]){
        if(!used[to]){
            lca_dfs(to, h+1);
            lca_dfs_list.push_back(ver);
        }
    }
}

struct node {
    int left, right, mmin, ver;
    node *child_left, *child_right;
};
node *root;

node *build(vector<int> &a, int l, int r){
    node *res = new node;
    res->left = l; res->right = r;
    if(l == r){
        res->child_left = res->child_right = nullptr;
        res->mmin = a[l];
        res->ver = lca_dfs_list[l];
    }
    else {
        int mid = (l+r) >> 1;
        res->child_left = build(a, l, mid);
        res->child_right = build(a, mid+1, r);
        if(res->child_left->mmin < res->child_right->mmin){
            res->mmin = res->child_left->mmin;
            res->ver = res->child_left->ver;
        }
        else {
            res->mmin = res->child_right->mmin;
            res->ver = res->child_right->ver;
        }
    }
    return res;
}

int query (node *root, int l, int r){
    if(root->left > r || l > root->right)return inf;
    if(root->left >= l && root->right <= r)return root->mmin;
    auto res1 = query(root->child_left, l, r);
    auto res2 = query(root->child_right, l, r);
    return min(res1, res2);
}

void prepare(/*������*/){
    lca_h.resize(kol_vo_ver);
    used.resize(kol_vo_ver, false);
    lca_dfs(/*������*/, 1);
    int m = lca_dfs_list.size();
    root = build(lca_dfs_list, 1, m);
    lca_first.resize(kol_vo_ver, -1);
    for(int i=0; i<m; i++){
        int ver = lca_dfs_list[i];
        if(lca_first[ver] == -1)
            lca_first[ver] = i;
    }
}

int lca(int a, int b){
    int left = lca_first[a];
    int right = lca_first[b];
    if(left > right)swap(left, right);
    return query(root, left, right);
}

int main()
{

    return 0;
}
