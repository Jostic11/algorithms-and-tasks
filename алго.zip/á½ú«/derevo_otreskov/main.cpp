#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct node {
    int left, right, kol_vo;
    node *child_left, *child_right;
};

node *build(int left, int right, vector<int> &a){
    node *res = new node;
    res->left = left;
    res->right = right;
    if(left == right){
        res->child_left = res->child_right = 0;
        if(a[left] < )
    }
    else {
        int mid = (left + right) / 2;
        res->child_left = build(left, mid, a);
        res->child_right = build(mid+1, right, a);
        res->mmax = max(res->child_left->mmax, res->child_right->mmax);
    }
    return res;
}

const int INF = 2000000000;
int query(node *root, int left, int right){
    if(right < root->left || left > root->right)return -INF;
    if(left <= root->left && root->right <= right)return root->mmax + root->add;
    int ans1 = query(root->child_left, left, right);
    int ans2 = query(root->child_right, left, right);
    return max(ans1, ans2) + root->add;
}

void uppdate(node *root, int left, int right, int delta){
    if(right < root->left || left > root->right)return;
    if(left <= root->left && root->right <= right){
        root->add += delta;
        return;
    }
    uppdate(root->child_left, left, right, delta);
    uppdate(root->child_right, left, right, delta);
    root->mmax = max(root->child_left->mmax + root->child_left->add,
                     root->child_right->mmax + root->child_right->add);
}

/*
struct node {
    int left, right, val;
    node *child_left, *child_right;
};

node *build(int left, int right, vector<int> &a){
    node *res = new node;
    res->left = left;
    res->right = right;
    if(left == right){
        res->child_left = res->child_right = 0;
        res->val = a[left];
    }
    else {
        int mid = (left + right) / 2;
        res->child_left = build(left, mid, a);
        res->child_right = build(mid+1, right, a);
        res->val = 0;
    }
    return res;
}

const int INF = 2000000000;
int query(node *root, int i){
    if(i < root->left || i > root->right)return 0;
    if(root->left == root->right)return root->val;
    int ans1 = query(root->child_left, i);
    int ans2 = query(root->child_right, i);
    return ans1+ans2+root->val;
}

void uppdate(node *root, int left, int right, int delta){
    if(right < root->left || left > root->right)return;
    if(left <= root->left && root->right <= right){
        root->val += delta;
        return;
    }
    uppdate(root->child_left, left, right, delta);
    uppdate(root->child_right, left, right, delta);
}
*/
int main()
{
    const int n = 100;
    vector<int> a(n+1);
    for(int i=1; i<=n; i++)
        a[i] = i%10;
    node *root = build(1, n, a);
    cout << query(root, 23, 35) << endl;
    uppdate(root, 10, 90, 10);
    cout << query(root, 23, 35) << endl;
    uppdate(root, 1, 25, 10);
    cout << query(root, 23, 35) << endl;
    uppdate(root, 33, 34, 100);
    cout << query(root, 23, 35) << endl;
    return 0;
}
