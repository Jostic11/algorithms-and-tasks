#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
const int inf = 1000000000;

int kol_vo;
vector<int> t;

void init(){
    t.resize(kol_vo);
}

void add(int pos){
    for(int i=pos; i<kol_vo; i|=(i+1))
        t[i]++;
}

int rsq(int r){
    int ans = 0;
    for(int i=r; i>=0; i = (i&(i+1))-1)
        ans += t[i];
    return ans;
}

int main()
{
    cin >> kol_vo;
    init();
    vector<int> v(kol_vo);
    for(int c=0; c<kol_vo; c++)
        cin >> v[c];
    for(int i=0; i<kol_vo; i++)
        if(v[i] == 0)add(i);
    int kol;
    cin >> kol;
    for(int i=0; i<kol; i++){
        int l, r;
        cin >> l >> r;
        if(l == 1)cout << rsq(r-1) << " ";
        else cout << rsq(r-1) - rsq(l-2) << " ";
    }
    return 0;
}
