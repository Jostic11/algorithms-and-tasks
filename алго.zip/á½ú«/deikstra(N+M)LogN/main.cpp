#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const int inf = 1000000000;

int main()
{
    int kol_vo_ver, kol_vo_reb;
    cin >> kol_vo_ver >> kol_vo_reb;
    vector<vector<pair<int, int> > > v(kol_vo_ver);
    for(int c=0; c<kol_vo_reb; c++){
        int e, e1, len;
        cin >> e >> e1 >> len;
        e--; e1--;
        v[e].push_back({e1, len});
        v[e1].push_back({e, len});
    }
    vector<int> dist(kol_vo_ver, inf), pred(kol_vo_ver);
    dist[0] = 0;
    set<pair<int, int> > q;
    q.insert({0, 0});
    while(!q.empty()){
        int ver = q.begin()->second;
        q.erase(q.begin());
        for(int c=0; c<v[ver].size(); c++){
            int to = v[ver][c].first;
            int len = v[ver][c].second;
            if(dist[ver] + len < dist[to]){
                q.erase({dist[to], to});
                dist[to] = dist[ver] + len;
                pred[to] = ver;
                q.insert({dist[to], to});
            }
        }
    }
    for(auto i : dist)
        cout << i << " ";
    return 0;
}
