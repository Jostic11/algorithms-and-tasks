#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
const ll inf = 1000000000;
typedef double db;
typedef pair<ll, ll> pll;
const ll mod1 = (1ll<<55)-55;//2^55-55
const ll mod2 = (1ll<<45)-55;//2^45-55

vector<vector<int> > v, answ, dop;
int kol_vo, k;

void init(){
    v.resize(kol_vo);
    for(int c=0; c<kol_vo; c++)
        v[c].resize(kol_vo);
    answ = v;
}

vector<vector<int> > mul(vector<vector<int> > a, vector<vector<int> > b){
    for(int i=0; i<kol_vo; i++){
        for(int j=0; j<kol_vo; j++){
            int kol = inf;
            for(int k=0; k<kol_vo; k++){
                kol = min(kol, a[i][k] + b[k][j]);
            }
            answ[i][j] = kol;
        }
    }
    return answ;
}

vector<vector<int> > mpow(vector<vector<int> > &a, int k){
    if(k == 1)return a;
    if(k % 2)return mul(mpow(a, k-1), a);
    else {
        dop = mpow(a, k/2);
        return mul(dop, dop);
    }
}

void prin(vector<vector<int> > &a){
    cout << endl;
    for(int c=0; c<a.size(); c++){
        for(int i=0; i<a[c].size(); i++)
            cout << a[c][i] << " ";
        cout << endl;
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    //freopen("gagarincup.in", "r", stdin);
    //freopen("output.txt", "w", stdout);

    cin >> kol_vo >> k;
    init();
    for(int c=0; c<kol_vo; c++){
        for(int i=0; i<kol_vo; i++){
            cin >> v[c][i];
            if(v[c][i] == 0)v[c][i] = inf;
        }
    }
    answ = mpow(v, k);
    prin(answ);
    return 0;
}

/*

3 4
0 2 5
0 0 1
4 0 0

*/
