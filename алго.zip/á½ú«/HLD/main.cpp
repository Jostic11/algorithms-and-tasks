#include <bits/stdc++.h>

using namespace std;

//#define int long long
const int inf = 1000000000;

int l = 30;
const int maxn = 100001;
int kol_vo, timer=0, poshld = 0;
vector<vector<int> > v, up;
vector<int> tin, tout, sz;

vector<int> hld[maxn];
pair<int, int> dop[maxn];
int nextver[maxn];

void init(){
    v.resize(kol_vo);
    tin.resize(kol_vo);
    tout.resize(kol_vo);
    up.resize(kol_vo, vector<int> (l));
    sz.resize(kol_vo);
}

/// ST

struct node {
    int l, r, mmax;
    node *left, *right;
};

node *vroot[maxn];

node *build(int l, int r){
    node *res = new node;
    res->l = l;
    res->r = r;
    res->mmax = 0;
    if(l == r){
        res->left = res->right = nullptr;
    }
    else {
        int mid = (l+r) / 2;
        res->left = build(l, mid);
        res->right = build(mid+1, r);
    }
    return res;
}

int query(node *root, int l, int r){
    if(root->l > r || root->r < l)return -inf;
    if(root->l >= l && root->r <= r)return root->mmax;
    int res1 = query(root->left, l, r);
    int res2 = query(root->right, l, r);
    return max(res1, res2);
}

void update(node *root, int pos, int val){
    if(root->l > pos || root->r < pos)return;
    if(root->l == root->r){
        root->mmax += val;
        return;
    }
    update(root->left, pos, val);
    update(root->right, pos, val);
    root->mmax = max(root->left->mmax, root->right->mmax);
}

/// lca

void dfs(int ver, int pr = 0){
    tin[ver] = timer++;
    up[ver][0] = pr;
    for(int i=1; i<l; i++)
        up[ver][i] = up[up[ver][i-1]][i-1];
    for(auto to : v[ver])
        if(to != pr)dfs(to, ver);
    tout[ver] = timer++;
}

bool upper(int a, int b){
    if(tin[a] <= tin[b] && tout[a] >= tout[b])return true;
    return false;
}

int lca(int a, int b){
    if(upper(a, b))return a;
    if(upper(b, a))return b;
    for(int i=l-1; i>=0; i--)
        if(!upper(up[a][i], b))a = up[a][i];
    return up[a][0];
}

/// HLD

void dfs1(int ver, int pr = -1){
    sz[ver] = 1;
    for(auto to : v[ver]){
        if(to != pr){
            dfs1(to, ver);
            sz[ver] += sz[to];
        }
    }
}

void dfs2(int ver, int pr = -1, int pos = 0){
    int big_ver = -1, sz_v = -1;
    for(auto to : v[ver]){
        if(pr != to && sz[to] > sz_v){
            //dfs2(to, ver);
            sz_v = sz[to];
            big_ver = to;
        }
    }
    if(big_ver == -1){
        hld[poshld].push_back(ver);
        dop[ver] = {poshld++, 0};
    }
    else {
        for(auto to : v[ver]){
            if(to != pr){
                dfs2(to, ver, pos+1);
                nextver[dop[to].first] = ver;
            }
        }
        hld[dop[big_ver].first].push_back(ver);
        dop[ver] = {dop[big_ver].first, hld[dop[big_ver].first].size()-1};
    }
}

int hld_max(int a, int lc){
    int now = a, mmax = -inf, res1;

    while(true){
        if(dop[now].first == dop[lc].first){
            res1 = query(vroot[dop[now].first], dop[now].second, dop[lc].second);
            mmax = max(mmax, res1);
            break;
        }
        else {
            res1 = query(vroot[dop[now].first], dop[now].second, hld[dop[now].first].size()-1);
            now = nextver[dop[now].first];
        }
        mmax = max(mmax, res1);
    }
    return mmax;
}

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    //freopen("output.txt", "w", stdout);

    cin >> kol_vo;
    init();
    for(int c=0; c<kol_vo-1; c++){
        int e, e1;
        cin >> e >> e1;
        e--; e1--;
        v[e].push_back(e1);
        v[e1].push_back(e);
    }
    dfs(0);
    dfs1(0);
    dfs2(0, -1, 0);

    for(int c=0; hld[c].size(); c++){
        vroot[c] = build(0, hld[c].size()-1);
    }

    int ask;
    cin >> ask;
    for(int c=0; c<ask; c++){
        char t;
        cin >> t;
        if(t == 'I'){
            int pos, val;
            cin >> pos >> val;
            pos--;
            update(vroot[dop[pos].first], dop[pos].second, val);
        }
        else {
            int a, b;
            cin >> a >> b;
            a--; b--;
            int lc = lca(a, b);
            int mx1 = hld_max(a, lc);
            int mx2 = hld_max(b, lc);
            cout << max(mx1, mx2) << endl;
        }
    }
    return 0;
}
