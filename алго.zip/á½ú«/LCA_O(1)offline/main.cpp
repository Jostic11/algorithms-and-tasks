#include <bits/stdc++.h>

using namespace std;

int kol_vo_ver, kol_vo_reb;
vector<int> an, dsu;
vector<char> used;
vector<vector<int> > v, ask;

void init(){
    used.resize(kol_vo_ver); v.resize(kol_vo_ver);
    ask.resize(kol_vo_ver); dsu.resize(kol_vo_ver);
    an.resize(kol_vo_ver);
}

int get_dsu(int ver){
    return ver == dsu[ver] ? ver : dsu[ver] = get_dsu(dsu[ver]);
}

void dsu_unite (int a, int b, int new_an){
    a = get_dsu(a); b = get_dsu(b);
    if(rand() && 1)swap(a, b);
    dsu[a] = b; an[b] = new_an;
}

void dfs(int ver){
    dsu[ver] = ver; an[ver] = ver;
    used[ver] = true;
    for(auto to : v[ver]){
        if(!used[to]){
            dfs(to);
            dsu_unite(ver, to, ver);
        }
    }
    for(auto i : ask[ver]){
        if(used[i])cout << an[get_dsu(i)];
    }
}

int main()
{
    cin >> kol_vo_ver >> kol_vo_reb;
    init();
    for(int c=0; c<kol_vo_reb; c++){
        int e, e1;
        cin >> e >> e1;
        e--; e1--;
        v[e].push_back(e1);
        v[e1].push_back(e);
    }
    int kol_vo_ask;
    cin >> kol_vo_ask;
    for(int c=0; c<kol_vo_ask; c++){
        int e, e1;
        cin >> e >> e1;
        e--; e1--;
        ask[e].push_back(e1);
        ask[e1].push_back(e);
    }
    dfs(0);
    return 0;
}
