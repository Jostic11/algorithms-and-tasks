#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
const ll inf = 1000000000;

vector<vector<int> > v;
vector<int> lm, rm;
vector<char> used;
int kol_vo, mmin;

void init(){
    v.resize(kol_vo);
    for(int c=0; c<kol_vo; c++)
        v[c].resize(kol_vo);
    lm.resize(kol_vo, -1);
    rm.resize(kol_vo, -1);
    used.resize(kol_vo);
}

bool dfs(int ver){
    for(int c=0; c<kol_vo; c++){
        if(!v[ver][c] || used[c])continue;
        used[c] = true;
        if(rm[c] == -1 || dfs(rm[c])){
            lm[ver] = c;
            rm[c] = ver;
            return true;
        }
    }
    return false;
}

void prin(vector<vector<int> > &a){
    cout << endl << endl;
    for(auto i : a){
        for(int j : i){
            cout << j << " ";
        }
        cout << endl;
    }
}

void prinset(set<int> st){
    cout << endl << endl;
    for(auto i : st)
        cout << i << " ";
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);


    cin >> kol_vo;
    vector<vector<int> > fir(kol_vo, vector<int> (kol_vo));
    for(int c=0; c<kol_vo; c++){
        for(int i=0; i<kol_vo; i++)
            cin >> fir[c][i];
    }
    int d = 1;
    set<int> Xnow, Ynow;
    vector<vector<int> > now = fir;
    init();
    vector<int> Xm;
    while(true){
        if(d > 1){
            mmin = inf;
            for(int c=0; c<kol_vo; c++){
                for(int i=0; i<kol_vo; i++){
                    if(Xnow.find(c) != Xnow.end() && Ynow.find(i) == Ynow.end())
                        mmin = min(mmin, now[c][i]);
                }
            }
            for(int c=0; c<kol_vo; c++){
                for(int i=0; i<kol_vo; i++){
                    if(Xnow.find(c) != Xnow.end())now[c][i] -= mmin;
                    if(Ynow.find(i) != Ynow.end())now[c][i] += mmin;
                }
            }
        }
        else {
            for(int c=0; c<kol_vo; c++){
                mmin = inf;
                for(int i=0; i<kol_vo; i++)
                    mmin = min(mmin, now[c][i]);
                for(int i=0; i<kol_vo; i++)
                    now[c][i] -= mmin;
            }
            for(int i=0; i<kol_vo; i++){
                mmin = inf;
                for(int c=0; c<kol_vo; c++)
                    mmin = min(mmin, now[c][i]);
                for(int c=0; c<kol_vo; c++)
                    now[c][i] -= mmin;
            }
        }

        Ynow.clear(); Xnow.clear();

        for(int c=0; c<kol_vo; c++){
            for(int i=0; i<kol_vo; i++){
                if(now[c][i] == 0)v[c][i] = 1;
                else v[c][i] = 0;
            }
        }
        memset(&lm[0], -1, sizeof(lm[0]) * lm.size());
        memset(&rm[0], -1, sizeof(rm[0]) * rm.size());

        bool b = true;
        while(b){
            b = false;
            memset(&used[0], 0, used.size() * sizeof(used[0]));
            for(int c=0; c<kol_vo; c++)
                if(lm[c] == -1 && dfs(c))b = true;
        }
        int kol = 0;
        for(int c=0; c<kol_vo; c++)
            if(lm[c] != -1)kol++;
/*
        if(d < 5)prin(now);
*/
        if(kol == kol_vo)break;
        for(int c=0; c<kol_vo; c++){
            if(lm[c] == -1){
                for(int i=0; i<kol_vo; i++){
                    if(!v[c][i] || rm[i] == -1)continue;
                    Ynow.insert(i);
                    Xnow.insert(rm[i]);
                    Xnow.insert(c);
                }
            }
        }
        d++;
/*
        if(d < 5)prinset(Xnow);
        if(d < 5)prinset(Ynow);
*/
    }
    int all = 0;
    for(int c=0; c<kol_vo; c++){
        all += fir[c][lm[c]];
    }
    cout << all << endl;
    for(int c=0; c<kol_vo; c++){
        cout << c+1 << " " << lm[c] + 1 << endl;
    }
    return 0;
}
