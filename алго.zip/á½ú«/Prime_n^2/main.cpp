#include <iostream>
#include <vector>
#include <algorithm>
#include <set>

using namespace std;

typedef long long ll;

const int INF = 100000000;

int main()
{
    int kol_vo_ver;
    cin >> kol_vo_ver;
    vector<bool> used(kol_vo_ver);
    vector<vector<int> > graph(kol_vo_ver, vector<int> (kol_vo_ver));
    for(int c=0; c<kol_vo_ver; c++)
        for(int i=0; i<kol_vo_ver; i++)
            cin >> graph[c][i];
    for(int c=0; c<kol_vo_ver; c++)
        for(int i=0; i<kol_vo_ver; i++)
            graph[c][i] == 0 ? graph[c][i] = INF : graph[c][i] = 1;
    vector<int> min_weight(kol_vo_ver, INF), end_of_min_w(kol_vo_ver, -1);
    min_weight[0] = 0;
    int kol = 0;
    for(int c=0; c<kol_vo_ver; c++){
        for(int i=0; i<kol_vo_ver; i++){
            if(graph[c][i] != INF) kol++;
        }
    }
    if(kol/2 > kol_vo_ver-1){
        cout << "NO";
        return 0;
    }
    for(int c=0; c<kol_vo_ver; c++){
        int ver = -1;
        for(int i=0; i<kol_vo_ver; i++)
            if(!used[i] && (ver == -1 || min_weight[i] < min_weight[ver]))ver = i;
        if(min_weight[ver] == INF){
            cout << "NO";
            return 0;
        }
        used[ver] = true;
        for(int to=0; to<kol_vo_ver; to++){
            if(!used[to] && graph[ver][to] < min_weight[to]){
                min_weight[to] = graph[ver][to];
                end_of_min_w[to] = ver;
            }
        }
    }
    cout << "YES";
    return 0;
}
