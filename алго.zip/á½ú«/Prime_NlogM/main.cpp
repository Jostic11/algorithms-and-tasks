#include <iostream>
#include <vector>
#include <algorithm>
#include <set>

using namespace std;

typedef long long ll;

const int INF = 100000000;

int main()
{
    int kol_vo_ver, kol_vo_reb;
    cin >> kol_vo_ver >> kol_vo_reb;
    vector<vector<int> > v(kol_vo_ver);
    for(int c=0; c<kol_vo_reb; c++){
        int e, e1;
        cin >> e >> e1;
        v[e-1].push_back(e1-1);
        v[e1-1].push_back(e-1);
    }
    set<pair<int, int> > q;
    vector<int> min_len(kol_vo_ver, INF), last(kol_vo_ver, -1);
    vector<bool> used(kol_vo_ver);
    q.insert({0, 0});
    used[0] = true;
    for(int c=0; c<kol_vo_ver; c++){
        int ver = q.begin()->second;
        q.erase(q.begin());
        if(last[ver] != -1)cout << ver+1 << " " << last[ver]+1 << endl;
        used[ver] = true;
        for(auto i : v[ver]){
            if(used[i])continue;
            q.erase({min_len[i], i});
            min_len[i] = 1;
            last[i] = ver;
            q.insert({min_len[i], i});
        }
    }
    return 0;
}
