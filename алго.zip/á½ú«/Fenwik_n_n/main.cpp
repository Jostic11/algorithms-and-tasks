#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
const int inf = 1000000000;

int kol_vo;
vector<vector<int> > t;

void init(){
    t.resize(kol_vo+1);
    for(int c=0; c<kol_vo+1; c++)
        t[c].resize(kol_vo+1);
}

void add(int x, int y){
    for(int i=x; i<=kol_vo; i|=i+1)
        for(int j=y; j<=kol_vo; j|=j+1)
            t[i][j]++;
}

int rsq(int x2, int y2){
    int res = 0;
    for(int i=x2; i>=1; i=(i&(i+1))-1)
        for(int j=y2; j>=1; j=(j&(j+1))-1)
            res += t[i][j];
    return res;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);

    int ask;
    cin >> kol_vo >> ask;
    init();
    string s;
    for(int i=0; i<ask; i++){
        cin >> s;
        if(s == "add"){
            int x, y;
            cin >> x >> y;
            add(x, y);
        }
        else {
            int x1, y1, x2, y2;
            cin >> x2 >> y2 >> x1 >> y1;
            cout << rsq(x1, y1) + rsq(x2-1, y2-1) - rsq(x1, y2-1) - rsq(x2-1, y1) << endl;
        }
    }/*
    for(int c=0; c<=kol_vo; c++){
        for(int i=0; i<=kol_vo; i++){
            cout << t[c][i] << " ";
        }
        cout << endl;
    }*/
    return 0;
}
