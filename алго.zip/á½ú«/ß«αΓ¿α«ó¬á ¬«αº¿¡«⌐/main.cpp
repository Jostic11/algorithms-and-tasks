#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;

int main()
{
    ifstream fin("input.txt");
    ofstream fout("output.txt");

    int kol_vo;
    fin >> kol_vo;
    vector<int> v(kol_vo);
    for(int c=0; c<kol_vo; c++)
        fin >> v[c];
    /*sort(v.begin(), v.end());
    for(int c=0; c<kol_vo; c++)
        fout << v[c] << " ";*/
    vector<vector<int> > kor(50001);
    for(int c=0; c<kol_vo; c++){
        kor[v[c]/2].push_back(v[c]);
    }
    for(int c=0; c<50001; c++){
        int len = kor[c].size();
        for(int i=0; i<len; i++)
            for(int y=0; y+1<len; y++)
                if(kor[c][y] > kor[c][y+1])swap(kor[c][y], kor[c][y+1]);
    }
    vector<int> answ;
    for(int c=0; c<50001; c++){
        int len = kor[c].size();
        for(int i=0; i<len; i++)
            answ.push_back(kor[c][i]);
    }
    for(int c=0; c<kol_vo; c++)
        fout << answ[c] << " ";
    return 0;
}
