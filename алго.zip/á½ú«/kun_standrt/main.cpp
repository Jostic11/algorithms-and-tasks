#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
const int inf = 1000000000;

int n, m;
vector<vector<int> > v, w;
vector<int> lm, rm;
vector<char> used;

void init(){
    v.resize(m);
    used.resize(n);
    lm.resize(m, -1);
    rm.resize(n, -1);
}

bool dfs(int ver){
    for(auto to : v[ver]){
        if(used[to])continue;
        used[to] = true;
        if(rm[to] == -1 || dfs(rm[to])){
            lm[ver] = to;
            rm[to] = ver;
            return true;
        }
    }
    return false;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);

    cin >> n >> m;
    init();
    vector<int> dop(4);
    for(int c=0; c<m; c++){
        cin >> dop[1];
        cin >> dop[2];
        cin >> dop[0];
        dop[3] = c;
        w.push_back(dop);
    }
    sort(w.begin(), w.end());
    reverse(w.begin(), w.end());
    for(int c=0; c<m; c++){
        v[c].push_back(w[c][1]-1);
        v[c].push_back(w[c][2]-1);
    }
    bool b = true;
    for(int c=0; c<m; c++){
        memset(&used[0], 0, sizeof(used[0])*used.size());
        if(lm[c] == -1)dfs(c);
    }
    ll answ = 0;
    for(int c=0; c<m; c++){
        if(lm[c] != -1)answ += w[c][0];
    }
    cout << answ;
    return 0;
}
