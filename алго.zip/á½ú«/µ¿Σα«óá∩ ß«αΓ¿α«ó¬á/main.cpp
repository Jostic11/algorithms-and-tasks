#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <string>

using namespace std;

int main()
{
    ifstream fin("input.txt");
    ofstream fout("output.txt");

    int kol_vo;
    fin >> kol_vo;
    vector<string> v(kol_vo);
    vector<int> dop(kol_vo), dop1(kol_vo);
    for(int c=0; c<kol_vo; c++)
        dop[c] = c;
    for(int c=0; c<kol_vo; c++)
        fin >> v[c];
    sort(v.begin(), v.end());
    /*for(int c=9; c>=0; c--){
        vector<int> coun(26), start(26);
        for(int i=0; i<kol_vo; i++)
            coun[int(v[dop[i]][c])-97]++;
        for(int i=1; i<26; i++)
            start[i] = coun[i-1] + start[i-1];
        for(int i=0; i<kol_vo; i++){
            dop1[start[int(v[dop[i]][c])-97]] = dop[i];
            start[int(v[dop[i]][c])-97]++;
        }
        swap(dop, dop1);
    }*/
    for(int c=0; c<kol_vo; c++)
        fout << v[dop[c]] << endl;
    fin.close();
    fout.close();
    return 0;
}
