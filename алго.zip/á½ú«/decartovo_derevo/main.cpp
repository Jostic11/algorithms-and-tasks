#include <iostream>
#include <cstdlib>

using namespace std;

struct node {
    int x, y;
    node *left, *right;

    node(int val){
        x = val;
        y = (rand() << 15) + rand();
        left = nullptr;
        right = nullptr;
    }

    ~node(){
        if(left)delete[] left;
        if(right)delete[] right;
    }
};

node *create(int kol_vo){
    if(!kol_vo)return nullptr;
    else {
        node *res = new node(now2++, kol_vo);
        kol_vo--;
        int mid = kol_vo/2;
        res->left = create(mid);
        res->right = create(kol_vo-mid);
        return res;
    }
}

bool exists(node *root, int key){
    if(root == nullptr)return false;
    if(key == root->x)return true;
    if(key > root->x)return exists(root->right, key);
    else exists(root->left, key);

}
pair <node *, node *> split(node *root, int val){
    if(root == nullptr)return{nullptr, nullptr};
    if(root->x <= val){
        auto res = split(root->right, val);
        root->right = res.first;
        return {root, res.second};
    }
    else {
        auto res = split(root->left, val);
        root->left = res.second;
        return {res.first, root};
    }
}

node * merg(node *root1, node *root2){
    if(root1 == nullptr)return root2;
    if(root2 == nullptr)return root1;
    if(root1->y < root2->y){
        root1->right = merg(root1->right, root2);
        return root1;
    }
    else {
        root2->left = merg(root1, root2->left);
        return root2;
    }
}

node * inser(node *root, int val){
    if(exists(root, val))return root;
    auto res = split(root, val);
    node *newnode = new node(val);
    return merg(merg(res.first, newnode), res.second);
}

node *eras(node *root, int val){
    if(!exists(root, val))return root;
    auto res1 = split(root, val);
    auto res2 = split(res1.first, val-1);
    delete res2.second;
    return merg(res2.first, res1.second);
}

void print(node *root){
    if(root == nullptr)return;
    print(root->left);
    cout << root->x << " ";
    print(root->right);
}

int main()
{
    node *root = nullptr;
    for(int i=10; i>=0; i--)
        root = inser(root, i);
    print(root);
    return 0;
}
