#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
int kol_vo_ver, kol_vo_reb;
vector<int> dvus, par, comp, rrank;
const int max_ver = 100005;

void init(){
    for(int c=0; c<kol_vo_ver; c++){
        dvus[c] = comp[c] = c;
        rrank[c] = 1;
        par[c] = -1;
    }
}

int get_dvus(int ver){
    if(ver == -1)return -1;
    return dvus[ver] == ver ? ver : dvus[ver] = get_dvus(dvus[ver]);
}

int get_comp(int ver){
    ver = get_dvus(ver);
    return comp[ver] == ver ? ver : comp[ver] = get_comp(par[ver]);
}
int cu = 0, lca;
vector<int> used(max_ver);

void merge_path(int a, int b){
    cu++; lca = -1;
    vector<int> va, vb;

    while(true){
        if(a != -1){
            a = get_dvus(a);
            va.push_back(a);
            if(used[a] == cu){
                lca = a;
                break;
            }
            used[a] = cu;
            a = par[a];
        }
        if(b != -1){
            b = get_dvus(b);
            va.push_back(b);
            if(used[b] == cu){
                lca = b;
                break;
            }
            used[b] = cu;
            b = par[b];
        }
    }
    int last = va[0];
    for(int c=1; c<va.size(); c++){
        if(rrank[last] > rrank[va[c]]){
            dvus[va[c]] = last;
        }
        else {
            dvus[last] = va[c];
            if(rrank[va[c]] == rrank[last])rrank[va[c]]++;
            last = va[c];
        }
        if(va[c] == lca)break;
    }
    last = vb[0];
    for(int c=1; c<vb.size(); c++){
        if(rrank[last] > rrank[vb[c]]){
            dvus[vb[c]] = last;
        }
        else {
            dvus[last] = vb[c];
            if(rrank[vb[c]] == rrank[last])rrank[vb[c]]++;
            last = vb[c];
        }
        if(vb[c] == lca)break;
    }
}

void add_edge(int a, int b){
    a = get_dvus(a);
    b = get_dvus(b);

    int ac = get_comp(a), bc = get_comp(b);
    if(ac != bc){
        if(rrank[ac] < rrank[bc]){
            par[a] = comp[a] = b;
            if(rrank[a] == rrank[b])rrank[b]++;
        }
    }
    else merge_path(a, b);
}

int main()
{
    return 0;
}
