#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
const int inf = 1000000000;

int norm(int i, int len){
    return (i % len + len) % len;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    //freopen("input.txt", "r", stdin);

    string s;
    cin >> s;
    s += "$";
    int n= s.size(), l = 1;
    vector<int> sm(n), c(n), k(n+1), sm_n(n), c_n(n);
    vector<pair<char, int> > v(n);
    for(int c=0; c<n; c++){
        v[c].first = s[c];
        v[c].second = c;
    }
    sort(v.begin(), v.end());
    int col = -1;
    for(int i=0; i<n; i++){
        sm[i] = v[i].second;
        if(i == 0 || v[i].first != v[i-1].first)col++;
        c[v[i].second] = col;
        k[col+1]++;
    }
    for(int i=1; i<n; i++)
        k[i] = k[i] + k[i-1];
    while(l < n){
        for(int i=0; i<n; i++){
            int j = norm(sm[i] - l, n);
            sm_n[k[c[j]]++] = j;
        }
        col = 0;
        for(int i=0; i<n; i++){
            if(i == 0 || c[sm_n[i]] != c[sm_n[i-1]] || c[norm(sm_n[i]+l, n)] != c[norm(sm_n[i-1]+l, n)])
                k[col++] = i;
            c_n[sm_n[i]] = col-1;
        }
        sm.swap(sm_n); c.swap(c_n); l *= 2;
    }
    for(int c=1; c<n; c++)
        cout << sm[c] + 1 << " ";
    cout << endl;

    vector<int> sm_r(n);
    for(int c=0; c<n; c++)
        sm_r[sm[c]] = c;
    vector<int> lcp(n);
    int z = 0;
    for(int j=0; j<n; j++){
        int i = sm_r[j];
        if(i == n-1)continue;
        int f = sm[i+1];
        while(s[j+z] == s[f+z])z++;
        lcp[i] = z;
        if(z > 0)z--;
    }
    for(int c=1; c<n-1; c++)
        cout << lcp[c] << " ";

    return 0;
}
