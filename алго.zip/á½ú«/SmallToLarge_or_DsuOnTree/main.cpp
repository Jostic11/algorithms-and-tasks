#include <bits/stdc++.h>

using namespace std;

//#define int long long
const int inf = 1000000000;

vector<vector<int> > v;
vector<int> sz, uk;
vector<set<int> > dop;
int kol_vo, x, y;

void init(){
    v.resize(kol_vo+2);
    sz.resize(kol_vo+2);
    dop.resize(kol_vo+2);
    uk.resize(kol_vo+2);
}

void dfs1(int ver, int pr = -1){
    sz[ver] = 1;
    for(auto to : v[ver]){
        if(to != pr){
            dfs1(to, ver);
            sz[ver] += sz[to];
        }
    }
}

int pos = 0;

void dfs(int ver, int pr = -1){
    int big_ver = -1, sz_max = -1;
    for(auto to : v[ver]){
        if(to != pr && sz[to] > sz_max){
            sz_max = sz[to];
            big_ver = to;
        }
        if(to != pr)dfs(to, ver);
    }
    if(big_ver == -1){
        uk[ver] = pos++;
        dop[uk[ver]].insert(1);
    }
    uk[ver] = uk[big_ver];
    for(auto to : v[ver]){
        if(to != pr && to != big_ver){
            for(auto i : dop[uk[to]])
                dop[uk[ver]].insert(i);
        }
    }
}

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    //freopen("output.txt", "w", stdout);
    //freopen("input.txt", "r", stdin);

    cin >> kol_vo;
    init();
    for(int c=0; c<kol_vo-1; c++){
        int e, e1;
        cin >> e >> e1;
        e--; e1--;
        v[e].push_back(e1);
        v[e1].push_back(e);
    }
    dfs1(0);
    dfs(0);
    return 0;
}
