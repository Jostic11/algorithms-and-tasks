#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
const ll inf = 1000000000;
typedef double db;
typedef pair<ll, ll> pll;
const ll mod1 = (1ll<<55)-55;//2^55-55
const ll mod2 = (1ll<<45)-55;//2^45-55

vector<vector<int> > answ(2, vector<int>(2)), dop;

vector<vector<int> > mul(vector<vector<int> > a, vector<vector<int> > b){
    for(int i=0; i<a.size(); i++){
        for(int j=0; j<a[i].size(); j++){
            int kol = 0;
            for(int p=0; p<a[i].size(); p++){
                kol += (a[i][p] * b[p][j]);
            }
            answ[i][j] = kol;
        }
    }
    return answ;
}

vector<vector<int> > mpow(vector<vector<int> > a, int n){
    if(n == 1)return a;
    if(n % 2)return mul(mpow(a, n-1), a);
    else {
        dop = mpow(a, n/2);
        return mul(dop, dop);
    }
}

void prin(vector<vector<int> > a){
    cout << endl << endl;
    for(int c=0; c<a.size(); c++){
        for(int i=0; i<a[c].size(); i++){
            cout << a[c][i] << " ";
        }
        cout << endl;
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    //freopen("gagarincup.in", "r", stdin);
    freopen("output.txt", "w", stdout);


    int n;
    cin >> n;
    vector<vector<int> > v(2, vector<int> (2, 1));
    v[1][1] = 0;
    if(n == 1){
        cout << 1 << endl;
        return 0;
    }
    v = mpow(v, n-1);
    cout << v[0][0];
    return 0;
}
