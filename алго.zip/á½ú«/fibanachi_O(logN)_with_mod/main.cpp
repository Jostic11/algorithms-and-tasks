#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
const ll inf = 1000000000;
typedef double db;
typedef pair<ll, ll> pll;
const ll mod1 = (1ll<<55)-55;//2^55-55
const ll mod2 = (1ll<<45)-55;//2^45-55

vector<vector<ll> > answ(2, vector<ll>(2)), dop;

vector<vector<ll> > mul(vector<vector<ll> > a, vector<vector<ll> > b){
    for(ll i=0; i<a.size(); i++){
        for(ll j=0; j<a[i].size(); j++){
            ll kol = 0;
            for(ll p=0; p<a[i].size(); p++){
                kol += (a[i][p] * b[p][j]);
            }
            answ[i][j] = kol;
        }
    }
    for(int c=0; c<answ.size(); c++){
        for(int i=0; i<answ[c].size(); i++)
            answ[c][i] %= inf;
    }
    return answ;
}

vector<vector<ll> > mpow(vector<vector<ll> > a, ll n){
    if(n == 1)return a;
    if(n % 2)return mul(mpow(a, n-1), a);
    else {
        dop = mpow(a, n/2);
        return mul(dop, dop);
    }
}

void prin(vector<vector<ll> > a){
    cout << endl << endl;
    for(ll c=0; c<a.size(); c++){
        for(ll i=0; i<a[c].size(); i++){
            cout << a[c][i] << " ";
        }
        cout << endl;
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    //freopen("gagarincup.in", "r", stdin);
    freopen("output.txt", "w", stdout);


    for(ll n=1; n<=200; n++){
        vector<vector<ll> > v(2, vector<ll> (2, 1));
        v[1][1] = 0;
        if(n == 1){
            cout << 1 << endl;
            continue;
        }
        v = mpow(v, n-1);
        cout << v[0][0] << endl;
    }
    return 0;
}
